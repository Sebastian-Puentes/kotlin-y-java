package com.example.proyectocalculadora

import org.junit.Assert.*

import org.junit.Test

class sumaTest {
    @Test
    fun testSuma() {
        val calculadora = Calculadora()
        val resultado: Double = calculadora.sumar(2.0, 3.0)
        assertEquals(5.0, resultado, 0.001)
    }
}