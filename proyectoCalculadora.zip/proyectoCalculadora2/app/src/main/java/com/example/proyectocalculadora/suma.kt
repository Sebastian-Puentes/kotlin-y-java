package com.example.proyectocalculadora

import android.widget.TextView

private val calculadora = Calculadora()


class Suma {
    fun sumar(num1: Double, num2: Double): Double {
        return num1 + num2
    }
}